=== Author or User Image ===
Plugin Name:Author or User Image
Contributors: www.zm-tech.net
Author: Md. Alimuzzaman Alim
Donate link: none
Tags: author, authors, image, avatar, widget, icon, post, list, zm-tech.
Requires at least: 3.5.0
Tested up to: 3.6.1
Version: 1.0.0
Stable tag: trunk
License: GPLv2

== Description == 
WordPress Author / User Image lets you set author image.
By this plugin you will be able to set author image.
This photo will be appears below the post in about author section and also in there comment. When you have many user your user's will be able to set there photo. It appears in comment. You have ability to resize the uploaded image. So no extra disk space or bandwidth will be loss. The most Amazing part of this plugin is you can set a default image for your user. If any of your user not set there image then show the default image.

 

 
=== WordPress Author / User Image: FEATURE ===

1. Set a default image for any user. (Who not set there Image)
2. Individually set user's image by user. (This image will be shown instead of the default image)

3. You can specify image size. (All image will be resize with this size before save)

4. You will also able to remove your image or the default image.

5. It shown just below your profile page in user section.

6. Control over the user’s image. (PRO)

7. Ability to remove user’s image. (PRO)

8. Ability to block any user from set his image. (PRO)

9. Ability to list all user who have set there image. (PRO)

10. Ability to list all users who is in your blacklist. (PRO)

 

== Installation ==

To Set Image:

1. You can add your photo or a default photo in "User >> Author Image".

2. If you want to set a default image you will find this at the top of the page.

3. Click on the browse button. Then select an image.

4. You can specify image size. So all image will be resized on that size.

5. At last click on save image to upload the image.

 

To Update Image:

1. If you want to update your image just upload as first time, then it will be replace your old image.

 

To Remove/Delete Image

1.  You can delete your image or default image. To delete your image go to "User >> Author Image" scroll down to the bottom. There you find like the image below.

== Changelog ==

1.0.0:First Version.

== Upgrade Notice ==

NO upgrade notice.

== Screenshots == 

http://www.zm-tech.net/wp-content/uploads/2013/10/WordPress-Author-User-Image-300x221.png

== Frequently Asked Questions == 

1. Its work well on first time but when change the image this take some time to change the image.

     Ans: Pleas clear your browser cache. If you have any cache plugin please clear the cache from that plugin.